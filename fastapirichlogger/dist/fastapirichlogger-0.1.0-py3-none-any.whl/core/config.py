class Settings:
    debug = False

settings = Settings()